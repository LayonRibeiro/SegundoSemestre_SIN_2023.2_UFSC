from viewLogin import ViewLogin
from viewMain import ViewMain


viewLogin = ViewLogin()
viewMain = ViewMain()

buttons = viewMain.open()

