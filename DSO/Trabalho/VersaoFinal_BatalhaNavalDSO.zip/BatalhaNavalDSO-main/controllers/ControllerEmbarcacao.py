class ControllerEmbarcacao:
    def __init__(self, controlador_main) -> None:
        self.__embarcacoes_jogador = []
        self.__embarcacoes_pc = []
        self.__controlador_main = controlador_main
            