class ViewMar:
    def ver_mar(self, mar: []):
        for i in range(0, len(mar)):
            print(mar[i])
